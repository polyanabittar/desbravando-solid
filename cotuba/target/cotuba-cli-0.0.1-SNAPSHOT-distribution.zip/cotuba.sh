#!/bin/bash
java -cp "libs/*" cotuba.cli.Main "$@"
